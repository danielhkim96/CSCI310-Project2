package backend.RecipeSearchFunction;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class RecipeSearch {
	public static void main(String[] args) {
		
		String s = null;
				
		try {
			String recipeSearch = "Pizza";
			int numResults = 5;
			
			String execStr = "python WebScraping/skinnytaste.py " + recipeSearch + " " + Integer.toString(numResults);
			
			// Run the python web scraping script with command line arguments
			Process p = Runtime.getRuntime().exec(execStr);
			
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
			
			String webScrapingResults = "";
			
			// read the output from the web scraper
			while ((s = stdInput.readLine()) != null) {
				webScrapingResults += s;
			}
			
			// Print out JSON string with recipe information
			System.out.println(webScrapingResults);
			
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
		
	}
}
