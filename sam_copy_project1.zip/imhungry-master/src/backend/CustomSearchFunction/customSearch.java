package customSearch;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.customsearch.Customsearch;
import com.google.api.services.customsearch.model.Result;
import com.google.api.services.customsearch.model.Result.Image;
import com.google.api.services.customsearch.model.Search;
import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.annotations.SerializedName;
import com.google.gson.reflect.TypeToken;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

// api key = AIzaSyBtByGx_WvuSFiwRFTgKYsVq92bU7gklyQ
// depedencies see https://developers.google.com/api-client-library/java/apis/customsearch/v1
public class customSearch {
	private static final int HTTP_REQUEST_TIMEOUT = 3 * 600000;
	
	// search function returns list of 10 results
	public static List<Result> search(String query){
		Customsearch customsearch= null;
	    String GOOGLE_API_KEY = "AIzaSyBtByGx_WvuSFiwRFTgKYsVq92bU7gklyQ";
	  
	    try {
	        customsearch = new Customsearch(new NetHttpTransport(),new JacksonFactory(), new HttpRequestInitializer() {
	            public void initialize(HttpRequest httpRequest) {
	                try {
	                    // set connect and read timeouts
	                    httpRequest.setConnectTimeout(HTTP_REQUEST_TIMEOUT);
	                    httpRequest.setReadTimeout(HTTP_REQUEST_TIMEOUT);

	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                }
	            }
	        });
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    List<Result> resultList=null;
	    try {
	        Customsearch.Cse.List list=customsearch.cse().list(query);
	        list.setKey(GOOGLE_API_KEY);
	        list.setCx("013729657631736132728:jnejgpg3sh0");
	        list.setSearchType("image");
	        Search results=list.execute();
	        resultList=results.getItems();
	    }
	    catch (  Exception e) {
	        e.printStackTrace();
	    }
	    return resultList;
	}
	public static void main(String[] args) throws IOException
	{
		List<Result> results = new ArrayList<>();

	    try {
	        results = search("basketball");
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    // convert to json string to send to front end
	    Gson gson = new Gson();
	    ArrayList<String> sendToFront = new ArrayList<>();
	    for(Result result : results){
	    	sendToFront.add(result.getLink());
	    }
	    String json = gson.toJson(sendToFront);
	    System.out.println(json);
	  
	}
}
