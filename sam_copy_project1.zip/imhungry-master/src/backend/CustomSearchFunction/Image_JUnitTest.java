package customSearch;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.jupiter.api.Test;

import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.customsearch.Customsearch;
import com.google.api.services.customsearch.model.Result;

public class Image_JUnitTest {

	Customsearch customsearch = null;
	private static final int HTTP_REQUEST_TIMEOUT = 3 * 600000;
	
	@Before
	public void setup() throws Exception {
		
		customsearch = new Customsearch(new NetHttpTransport(),new JacksonFactory(), new HttpRequestInitializer() {
            public void initialize(HttpRequest httpRequest) {
                try {
                    // set connect and read timeouts
                    httpRequest.setConnectTimeout(HTTP_REQUEST_TIMEOUT);
                    httpRequest.setReadTimeout(HTTP_REQUEST_TIMEOUT);

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

	}
	
	@Test
	public void testSearch() {
		
		List<Result> testResult = new ArrayList<>();
		testResult = customSearch.search("basketball");
		
		assertEquals("{\"displayLink\":\"en.wikipedia.org\",\"htmlSnippet\":\"<b>Basketball</b> - Wikipedia\",\"htmlTitle\":\"<b>Basketball</b> - Wikipedia\",\"image\":{\"byteSize\":16947097,\"contextLink\":\"https://en.wikipedia.org/wiki/Basketball\",\"height\":3983,\"thumbnailHeight\":112,\"thumbnailLink\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFb5r1FgwapyoJT1klmrrP143LrQMZsMTrF44xA5MeVIO6QuEfk67pIfey\",\"thumbnailWidth\":150,\"width\":5356},\"kind\":\"customsearch#result\",\"link\":\"https://upload.wikimedia.org/wikipedia/commons/3/3b/LeBron_James_Layup_%28Cleveland_vs_Brooklyn_2018%29.jpg\",\"mime\":\"image/jpeg\",\"snippet\":\"Basketball - Wikipedia\",\"title\":\"Basketball - Wikipedia\"}", testResult.get(0).toString());
		
	}
	
	@Test
	public void testSearchResult() {
		
		List<Result> testResult = new ArrayList<>();
		testResult = customSearch.search("basketball");
		
		assertEquals("[{\"displayLink\":\"en.wikipedia.org\",\"htmlSnippet\":\"<b>Basketball</b> - Wikipedia\",\"htmlTitle\":\"<b>Basketball</b> - Wikipedia\",\"image\":{\"byteSize\":16947097,\"contextLink\":\"https://en.wikipedia.org/wiki/Basketball\",\"height\":3983,\"thumbnailHeight\":112,\"thumbnailLink\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFb5r1FgwapyoJT1klmrrP143LrQMZsMTrF44xA5MeVIO6QuEfk67pIfey\",\"thumbnailWidth\":150,\"width\":5356},\"kind\":\"customsearch#result\",\"link\":\"https://upload.wikimedia.org/wikipedia/commons/3/3b/LeBron_James_Layup_%28Cleveland_vs_Brooklyn_2018%29.jpg\",\"mime\":\"image/jpeg\",\"snippet\":\"Basketball - Wikipedia\",\"title\":\"Basketball - Wikipedia\"}, {\"displayLink\":\"www.badensports.com\",\"htmlSnippet\":\"Elite Game <b>Basketball</b> - Baden Sports\",\"htmlTitle\":\"Elite Game <b>Basketball</b> - Baden Sports\",\"image\":{\"byteSize\":1331827,\"contextLink\":\"https://www.badensports.com/products/elite-game-basketball\",\"height\":1500,\"thumbnailHeight\":150,\"thumbnailLink\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGr7LpzsdO1kHPzLDBrnpVvtVv8DUwK02ZhhZ2N3zIktUufFUP4v7aN8C7MA\",\"thumbnailWidth\":150,\"width\":1500},\"kind\":\"customsearch#result\",\"link\":\"https://cdn.shopify.com/s/files/1/0712/4751/products/BX7E-02E_High_Large_TOP_2000x.png?v=1537468789\",\"mime\":\"image/png\",\"snippet\":\"Elite Game Basketball - Baden Sports\",\"title\":\"Elite Game Basketball - Baden Sports\"}, {\"displayLink\":\"en.wikipedia.org\",\"htmlSnippet\":\"<b>Basketball</b> (ball) - Wikipedia\",\"htmlTitle\":\"<b>Basketball</b> (ball) - Wikipedia\",\"image\":{\"byteSize\":72642,\"contextLink\":\"https://en.wikipedia.org/wiki/Basketball_(ball)\",\"height\":220,\"thumbnailHeight\":107,\"thumbnailLink\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRv0wYM7QlRiJYVJ7prC5q9Z4ibijJtPUiuVNCJR6whLYT4952OUQtUxHc\",\"thumbnailWidth\":107,\"width\":220},\"kind\":\"customsearch#result\",\"link\":\"https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Basketball.png/220px-Basketball.png\",\"mime\":\"image/png\",\"snippet\":\"Basketball (ball) - Wikipedia\",\"title\":\"Basketball (ball) - Wikipedia\"}, {\"displayLink\":\"www.covers.com\",\"htmlSnippet\":\"How to bet <b>basketball</b>\",\"htmlTitle\":\"How to bet <b>basketball</b>\",\"image\":{\"byteSize\":341393,\"contextLink\":\"https://www.covers.com/Editorial/Article/d999e1bb-4227-11e7-8764-005056830dca/How-to-bet-basketball-NBA-Betting-Odds-College-Basketball-Betting-March-Madness-Odds-NBA-pointspreads-NCAAB-Odds\",\"height\":513,\"thumbnailHeight\":93,\"thumbnailLink\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSooK5YPnmhwY8fuH5LOSLjyhxkomV1EfB3bdQnuSRA8oJamfZzbz8bVAKT\",\"thumbnailWidth\":142,\"width\":780},\"kind\":\"customsearch#result\",\"link\":\"https://images.covers.com/editorial/2017/basketball_betting061417.jpg\",\"mime\":\"image/jpeg\",\"snippet\":\"How to bet basketball\",\"title\":\"How to bet basketball\"}, {\"displayLink\":\"www.amazon.com\",\"htmlSnippet\":\"Amazon.com : Spalding NBA Official Game Ball <b>Basketball</b> (2014 ...\",\"htmlTitle\":\"Amazon.com : Spalding NBA Official Game Ball <b>Basketball</b> (2014 ...\",\"image\":{\"byteSize\":538758,\"contextLink\":\"https://www.amazon.com/Spalding-Official-Basketball-Retail-Packaging/dp/B00178UAP4\",\"height\":1466,\"thumbnailHeight\":147,\"thumbnailLink\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTdWZabvb4QGFNjcJKPVr8wO8-DuTrvFZRT3X_eiGTqxFzLpYi-f3jevwsBUQ\",\"thumbnailWidth\":150,\"width\":1500},\"kind\":\"customsearch#result\",\"link\":\"https://images-na.ssl-images-amazon.com/images/I/A1cd6TMkAML._SL1500_.jpg\",\"mime\":\"image/jpeg\",\"snippet\":\"Amazon.com : Spalding NBA Official Game Ball Basketball (2014 ...\",\"title\":\"Amazon.com : Spalding NBA Official Game Ball Basketball (2014 ...\"}, {\"displayLink\":\"www.espn.com\",\"htmlSnippet\":\"Women&#39;s <b>Basketball</b> - ESPN\",\"htmlTitle\":\"Women&#39;s <b>Basketball</b> - ESPN\",\"image\":{\"byteSize\":49957,\"contextLink\":\"http://www.espn.com/womens-basketball/\",\"height\":288,\"thumbnailHeight\":115,\"thumbnailLink\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTOmNX15e14sdjW_tqvn_wDdFMZtFrdIl9zl0mAa5bFwairohceXQ7vQYA\",\"thumbnailWidth\":115,\"width\":288},\"kind\":\"customsearch#result\",\"link\":\"http://a.espncdn.com/combiner/i?img=/redesign/assets/img/icons/ESPN-icon-basketball.png&w=288&h=288&transparent=true\",\"mime\":\"image/\",\"snippet\":\"Women's Basketball - ESPN\",\"title\":\"Women's Basketball - ESPN\"}, {\"displayLink\":\"www.amazon.com\",\"htmlSnippet\":\"Amazon.com : Spalding NBA Official Game <b>Basketball</b> : Sports &amp; Outdoors\",\"htmlTitle\":\"Amazon.com : Spalding NBA Official Game <b>Basketball</b> : Sports &amp; Outdoors\",\"image\":{\"byteSize\":57138,\"contextLink\":\"https://www.amazon.com/Spalding-NBA-Official-Game-Basketball/dp/B072BXLQX4\",\"height\":527,\"thumbnailHeight\":132,\"thumbnailLink\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3b89RqxZuDjYpD-ESuBoNUlcyqqUmCCSaHFV9wmchq1yqLNWGgsmiHgt8\",\"thumbnailWidth\":131,\"width\":522},\"kind\":\"customsearch#result\",\"link\":\"https://images-na.ssl-images-amazon.com/images/I/91FOeSuXvIL._SX522_.jpg\",\"mime\":\"image/jpeg\",\"snippet\":\"Amazon.com : Spalding NBA Official Game Basketball : Sports & Outdoors\",\"title\":\"Amazon.com : Spalding NBA Official Game Basketball : Sports & Outdoors\"}, {\"displayLink\":\"www.courier-journal.com\",\"htmlSnippet\":\"Big Ten, SEC foes highlight Louisville <b>basketball</b> schedule\",\"htmlTitle\":\"Big Ten, SEC foes highlight Louisville <b>basketball</b> schedule\",\"image\":{\"byteSize\":56423,\"contextLink\":\"https://www.courier-journal.com/story/sports/college/louisville/2018/08/24/big-ten-sec-foes-highlight-louisville-basketball-nonconference-schedule-2018/1083591002/\",\"height\":712,\"thumbnailHeight\":140,\"thumbnailLink\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTJwrvpgZIlQ-oKnZL41sZPJzkjKOfMB5wWO3vpoTAihk57Hka7bAdsPvWK\",\"thumbnailWidth\":105,\"width\":534},\"kind\":\"customsearch#result\",\"link\":\"https://www.gannett-cdn.com/-mm-/4d73b88f8a2aa3a1b36a019683e17c21bbbb30ab/c=172-0-3547-4500/local/-/media/2018/03/07/Louisville/Louisville/636560327957364871-UofL-FSU07-Sam.jpg?width=534&height=712&fit=crop\",\"mime\":\"image/jpeg\",\"snippet\":\"Big Ten, SEC foes highlight Louisville basketball schedule\",\"title\":\"Big Ten, SEC foes highlight Louisville basketball schedule\"}, {\"displayLink\":\"www.amazon.com\",\"htmlSnippet\":\"Amazon.com : Spalding NBA Street <b>Basketball</b> - Intermediate Size 6 ...\",\"htmlTitle\":\"Amazon.com : Spalding NBA Street <b>Basketball</b> - Intermediate Size 6 ...\",\"image\":{\"byteSize\":45189,\"contextLink\":\"https://www.amazon.com/Spalding-Parent-63-249-parent-NBA-Street-Basketball-x/dp/B01C8TVYJ6\",\"height\":428,\"thumbnailHeight\":126,\"thumbnailLink\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0Myjc5pqQGmZiEPZxV8HmMJQy8G3wOsactsfgTVk82CXmEs5mCna7UA\",\"thumbnailWidth\":125,\"width\":425},\"kind\":\"customsearch#result\",\"link\":\"https://images-na.ssl-images-amazon.com/images/I/916fCPkZDUL._SX425_.jpg\",\"mime\":\"image/jpeg\",\"snippet\":\"Amazon.com : Spalding NBA Street Basketball - Intermediate Size 6 ...\",\"title\":\"Amazon.com : Spalding NBA Street Basketball - Intermediate Size 6 ...\"}, {\"displayLink\":\"sports.yahoo.com\",\"htmlSnippet\":\"Montana high school <b>basketball</b> game ends 102-0\",\"htmlTitle\":\"Montana high school <b>basketball</b> game ends 102-0\",\"image\":{\"byteSize\":50515,\"contextLink\":\"https://sports.yahoo.com/high-school-girls-basketball-team-wins-102-0-034119019.html\",\"height\":598,\"thumbnailHeight\":107,\"thumbnailLink\":\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS74n1AVit7h2P5ssd5j58Yv_L2EkByIv2I7Bd-o6iNIZFWGxUFMzUPg2gc\",\"thumbnailWidth\":143,\"width\":800},\"kind\":\"customsearch#result\",\"link\":\"https://s.yimg.com/ny/api/res/1.2/umHJJQAzal.Ar.laG6bGWQ--~A/YXBwaWQ9aGlnaGxhbmRlcjtzbT0xO3c9ODAw/http://media.zenfs.com/en/homerun/feed_manager_auto_publish_494/b427d19dd6238628dc7fa8acc2c212d3\",\"mime\":\"image/\",\"snippet\":\"Montana high school basketball game ends 102-0\",\"title\":\"Montana high school basketball game ends 102-0\"}]", testResult.toString());
		
	}
	
	
}
