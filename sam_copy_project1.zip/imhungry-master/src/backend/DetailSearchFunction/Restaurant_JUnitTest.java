package backend;

import static org.junit.Assert.*;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;

public class Restaurant_JUnitTest {

	private Restaurant restaurant;
	private Restaurant_Info info;

	@Before
	public void setup() throws Exception {

		restaurant = new Restaurant();
		info = new Restaurant_Info();

	}

	@Test
	public void testRestaurantInfo() {

		info.setPlaceId("ChIJ7aVxnOTHwoARxKIntFtakKo");
		info.setName("USC");
		info.setAddress("University Campus, Los Angeles, CA 90007");
		info.setStars(5.0);
		info.setPriceRange("$$$$");
		info.setWebsite("usc.edu");
		info.setPhoneNumber("(213) 740-2311");
		info.setType("University");

		assertEquals("ChIJ7aVxnOTHwoARxKIntFtakKo", info.getPlaceId());
		assertEquals("USC", info.getName());
		assertEquals("University Campus, Los Angeles, CA 90007", info.getAddress());
		assertEquals(Double.valueOf(5.0), info.getStars());
		assertEquals("$$$$", info.getPriceRange());
		assertEquals("usc.edu", info.getWebsite());
		assertEquals("(213) 740-2311", info.getPhoneNumber());
		assertEquals("University", info.getType());

	}

	@Test
	public void testGoogleSearch() {

		restaurant.google_search("McDonald's");
		String placeId = "ChIJeWXfI8XHwoARwButZ-fwREY";
		assertEquals(placeId, restaurant.restaurant_info.getPlaceId());

	}

	@Test
	public void testGoogleDetail() {

		restaurant.google_search("Ebaes");
		restaurant.google_detail();

		assertEquals("Ebaes", restaurant.restaurant_info.getName());
		assertEquals("1111 Wilshire Blvd #104, Los Angeles, CA 90017, USA", restaurant.restaurant_info.getAddress());
		assertEquals("(213) 250-0088", restaurant.restaurant_info.getPhoneNumber());
		assertEquals(Double.valueOf(4.4), restaurant.restaurant_info.getStars());
		assertEquals("restaurant, point_of_interest, food, establishment", restaurant.restaurant_info.getType());
		assertEquals("N/A", restaurant.restaurant_info.getPriceRange());
		assertEquals("http://ebaesla.com/", restaurant.restaurant_info.getWebsite());

	}

	@Test
	public void testJsonObject() {

		restaurant.google_search("TrioHouse");
		restaurant.google_detail();
		JSONObject object = restaurant.getJsonObj();

		String jsonString = "{\"resaurant\":[{\"website\":\"http://www.triohousela.com/\",\"address\":\"3031 S Figueroa St, Los Angeles, CA 90007, USA\",\"phoneNumber\":\"(213) 741-0101\",\"name\":\"Trio House\",\"stars\":4.3,\"type\":\"restaurant, point_of_interest, food, establishment\",\"priceRange\":\"$$\"}]}";
		assertEquals(jsonString, object.toString());

	}

}
