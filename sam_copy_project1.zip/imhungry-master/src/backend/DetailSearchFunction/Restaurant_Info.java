package backend;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Restaurant_Info {

	@SerializedName("Restaurant_Info")
	@Expose
	private String placeId;
	private String name;
	private String address;
	private String phoneNumber;
	private String website;
	private Double stars;
	private int drivingTime;
	private String type;
	private String priceRange;
	
	public Restaurant_Info() {
		// TODO Auto-generated constructor stub
	}
	
	public void setPlaceId(String id) {
		this.placeId = id;
	}
	
	public String getPlaceId() {
		return placeId;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return this.address;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}
	
	public void setWebsite(String website) {
		this.website = website;
	}
	
	public String getWebsite() {
		return this.website;
	}
	
	public void setStars(Double stars) {
		this.stars = stars;
	}
	
	public Double getStars() {
		return this.stars;
	}
	
	public void setDrivingTime(int drivingTime) {
		this.drivingTime = drivingTime;
	}
	
	public int getDrivingTime() {
		return this.drivingTime;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return this.type;
	}
	
	public void setPriceRange(String priceRange) {
		this.priceRange = priceRange;
	}
	
	public String getPriceRange() {
		return priceRange;
	}

}