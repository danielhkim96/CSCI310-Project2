package backend;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sun.org.apache.xml.internal.security.algorithms.implementations.IntegrityHmac;

import sun.management.counter.Variability;

public class Restaurant {

	private String Google_Place_Api = "https://maps.googleapis.com/maps/api";

	private String Place = "/place";
	private String Distance = "/distancematrix";
	private String Search = "/findplacefromtext";
	private String Detail = "/details";
	private String JsonOutput = "/json";
	private String Api_Key = "AIzaSyCqBoG7IClVNU02fxe4ff34HzapuzeVB_M";
	private String placeId;
	private String distance;
	private String drivingTime;
	// Search restaurants around USC
	private String TommyTrojan = "34.020548,-118.285450";
	// within diameter 2000 meters
	private String circle = "circle:2000@";

	static JSONObject resultJObj = new JSONObject();

	protected Restaurant_Info restaurant_info = new Restaurant_Info();

	public void google_search(String infood) { // get the place id

		HttpURLConnection connection = null;
		String placeIdResult = "";

		try {
			URL url = new URL(Google_Place_Api + Place + Search + JsonOutput + "?input=" + infood
					+ "&inputtype=textquery" + "&fields=place_id" + "&locationbias=" + circle + TommyTrojan
					+ "&type=restaurant" + "&key=" + Api_Key);

			connection = (HttpURLConnection) url.openConnection();
			InputStreamReader isr = new InputStreamReader(connection.getInputStream());
			BufferedReader br = new BufferedReader(isr);

			// read the data from search result
			String temp;
			while ((temp = br.readLine()) != null) {
				placeIdResult += (temp) + "\n";
			}
			br.close();

		} catch (IOException ie) {
			System.out.println("ie: " + ie.getMessage());
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}

		JSONObject obj = new JSONObject(placeIdResult);
		JSONArray ary = obj.getJSONArray("candidates");

		// extract place ID from JsonArray
		for (int i = 0; i < ary.length(); i++) {
			placeId = ary.getJSONObject(i).getString("place_id");
			restaurant_info.setPlaceId(placeId);
		}

	}

	public void google_detail() { // search restaurant by place ID

		HttpURLConnection connection = null;
		String detailResult = "";

		try {
			URL url = new URL(Google_Place_Api + Place + Detail + JsonOutput + "?placeid=" + placeId
					+ "&fields=name,formatted_address,formatted_phone_number,website,rating,type,price_level" + "&key="
					+ Api_Key);

			connection = (HttpURLConnection) url.openConnection();
			InputStreamReader isr = new InputStreamReader(connection.getInputStream());
			BufferedReader br = new BufferedReader(isr);

			// read the data from detail result
			String temp;
			while ((temp = br.readLine()) != null) {
				detailResult += (temp) + "\n";
			}
			br.close();

		} catch (IOException ie) {
			System.out.println("ie: " + ie.getMessage());
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}

		JSONObject obj = new JSONObject(detailResult);
		JSONObject obj2 = obj.getJSONObject("result");

		// save the data in restaurant_info class
		restaurant_info.setName(obj2.has("name") ? obj2.getString("name") : "N/A");
		restaurant_info.setAddress(obj2.has("formatted_address") ? obj2.getString("formatted_address") : "N/A");
		restaurant_info
				.setPhoneNumber(obj2.has("formatted_phone_number") ? obj2.getString("formatted_phone_number") : "N/A");
		restaurant_info.setWebsite(obj2.has("website") ? obj2.getString("website") : "N/A");
		restaurant_info.setStars(obj2.has("rating") ? obj2.getDouble("rating") : -1);

		if (obj2.has("price_level")) {
			String dollarSign = "";
			switch ((int) obj2.getDouble("price_level")) {
			case 0:
				dollarSign = "Free!";
				break;
			case 1:
				dollarSign = "$";
				break;
			case 2:
				dollarSign = "$$";
				break;
			case 3:
				dollarSign = "$$$";
				break;
			case 4:
				dollarSign = "$$$$";
				break;
			}
			restaurant_info.setPriceRange(dollarSign);
		} else {
			restaurant_info.setPriceRange("N/A");
		}

		if (obj2.has("types")) {
			JSONArray ary = obj2.getJSONArray("types");
			String types = "";
			for (int i = 0; i < ary.length(); i++) {
				types += ary.getString(i);
				if (i < ary.length() - 1) {
					types += ", ";
				}
			}
			restaurant_info.setType(types);
		} else {
			restaurant_info.setType("N/A");
		}

	}

	public void google_distance_matrix() { // get distance

		HttpURLConnection connection = null;
		String distanceResult = "";

		try {
			URL url = new URL(Google_Place_Api + Distance + JsonOutput + "?units=imperial" + "&origins=" + TommyTrojan
					+ "&destinations=place_id:" + placeId + "&key=" + Api_Key);

			connection = (HttpURLConnection) url.openConnection();
			InputStreamReader isr = new InputStreamReader(connection.getInputStream());
			BufferedReader br = new BufferedReader(isr);

			// read the data from search result
			String temp;
			while ((temp = br.readLine()) != null) {
				distanceResult += (temp) + "\n";
			}
			br.close();

		} catch (IOException ie) {
			System.out.println("ie: " + ie.getMessage());
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}

		JSONObject obj = new JSONObject(distanceResult);
		JSONArray ary = obj.getJSONArray("rows");

		for (int i = 0; i < ary.length(); i++) {
			JSONArray ary2 = ary.getJSONObject(i).getJSONArray("elements");
			JSONObject obj2 = new JSONObject(ary2.getJSONObject(0).toString());
			JSONObject objdur = obj2.getJSONObject("duration");
			drivingTime = objdur.getString("text");
			restaurant_info.setDrivingTime(drivingTime);
			JSONObject objdis = obj2.getJSONObject("distance");
			distance = objdis.getString("text");
			restaurant_info.setDistance(distance);
		}

	}

	public JSONObject getJsonObj() { // make a json object for returning to frontend

		JSONObject obj = new JSONObject();
		JSONObject obj2 = new JSONObject();
		JSONArray ary = new JSONArray();

		obj.put("name", restaurant_info.getName());
		obj.put("name", restaurant_info.getName());
		obj.put("address", restaurant_info.getAddress());
		obj.put("phoneNumber", restaurant_info.getPhoneNumber());
		obj.put("website", restaurant_info.getWebsite());
		obj.put("stars", restaurant_info.getStars());
		obj.put("drivingTime", restaurant_info.getDrivingTime());
		obj.put("type", restaurant_info.getType());
		obj.put("priceRange", restaurant_info.getPriceRange());
		obj.put("distance", restaurant_info.getDistance());

		ary.put(obj);
		obj2.put("resaurant", ary);

		return obj2;

	}

	public static void main(String[] args) {

		Restaurant restaurant = new Restaurant();
		String request = "Italian"; // input user's request
		restaurant.google_search(request);
		restaurant.google_detail();
		restaurant.google_distance_matrix();
		resultJObj = restaurant.getJsonObj(); // form the data in Json Object

		System.out.println(resultJObj.toString());

	}

}