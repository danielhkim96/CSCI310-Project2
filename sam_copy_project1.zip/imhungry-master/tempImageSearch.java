
// place holder not yet working 
@Override
public List<Image> searchImages(String query) throws ImageSearchException {

    try {
        Customsearch customsearch = getCustomsearch();
        Customsearch.Cse.List list = customsearch.cse().list(query);
        list.setKey(key);
        list.setCx(cx);
        list.setSearchType("image");
        list.setImgSize("xlarge");
        list.setImgType("photo");

        Search results = list.execute();
        List<Image> images = new ArrayList<Image>();

        for (Result result : results.getItems()) {
            Image image = new Image();
            image.setSource("google");
            image.setUrl(result.getLink());
            image.setTitle(result.getTitle());
            images.add(image);
        }
        return images;

    } catch (IOException e) {
        throw new ImageSearchException(e.getMessage(), e.getCause());
    }
}
 

/* top 10 results?
    url = new URL("https://www.googleapis.com/customsearch/v1?key="+key+ "&cx="+ cx +"&q="+    searchText+"&alt=json"+"&start="+0+"&num="+30);
    HttpURLConnection conn2 = (HttpURLConnection) url.openConnection();
    System.out.println("Connection opened!");
    conn2.setRequestMethod("GET");
    conn2.setRequestProperty("Accept", "application/json");
    BufferedReader br = new BufferedReader(new InputStreamReader(
    (conn2.getInputStream())));
    */
