function getRecipe() {
    var request = require('request');
    var searchTerm = "chicken";
    var appId = "16adf4df";
    var appKey = "f56810c458e18cce4af254266f22339f"
    var numResults = "10";
    request('https://api.edamam.com/search?q=' + searchTerm + '&app_id=' + appId + '&app_key=' + appKey + '&to=' + numResults, 
                function (error, response, body) {
                    console.log('error:', error); // Print the error if one occurred
                    console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
                    console.log('body:', body); // Print the HTML for the Google homepage
                });
}

var getRecipe = function() {
    var searchTerm = "chicken";
    var appId = "16adf4df";
    var appKey = "f56810c458e18cce4af254266f22339f";
    var numResults = 10;
    var queryURL = "https://api.edamam.com/search?q=" + searchTerm + "&app_id=" + appId + "&app_key=" + appKey + "&to=" + numResults;
    $.ajax({
        url: queryURL,
        method: "GET",
    })
    .then(function(response) {
        var recipes = response.hits;

        for (var i = 0; i < recipes.length; i++) {
            var imageURL = response.hits[i].recipe.image;
            var recipeLabel = response.hits[i].recipe.label;
            var recipeURL = response.hits[i].recipe.url;
            var ingredients = response.hits[i].recipe.ingredientLines;
        }
    })
}