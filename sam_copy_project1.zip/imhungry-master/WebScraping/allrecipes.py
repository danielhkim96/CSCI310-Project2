import requests
import time
from bs4 import BeautifulSoup

def main():
    recipeSearch = input("ImHungry Search: ")

    page = requests.get("https://www.allrecipes.com/search/results/?wt=" + recipeSearch + "&sort=re")
    soup = BeautifulSoup(page.content, 'html.parser')
    # print(soup.prettify())
    # print(list(soup.children))
    for recipe in soup.find_all('article', class_='fixed-recipe-card'):
        time.sleep(1)
        recipeId = recipe.find(class_='favorite').attrs['data-id']
        recipeInfo = recipe.find('div', class_='fixed-recipe-card__info')
        recipeHeader = recipeInfo.find('h3', class_='fixed-recipe-card__h3')
        recipeLink = recipeHeader.find('a', class_='fixed-recipe-card__title-link')
        recipeNameText = recipeLink.text.strip()

        recipePage = requests.get("https://www.allrecipes.com/recipe/" + recipeId)
        soupRecipe = BeautifulSoup(recipePage.content, 'html.parser')

        recipeSummary = soupRecipe.find('section', class_='recipe-summary')
        recipeRating = recipeSummary.find('div', class_='rating-stars').attrs['data-ratingstars']
        recipeRating = round(float(recipeRating), 2)

        recipeIngredients = soupRecipe.find('section', class_='recipe-ingredients')
        # recipeCookTime = recipeIngredients.find(class_='ready-in-time').text

        recipeIngredientsList = list()
        for ingredient in soupRecipe.find_all('li', class_='checkList__line'):
            if ingredient.get_text(strip=True) not in (
                'Add all ingredients to list',
                '',
                'ADVERTISEMENT'
            ):
                recipeIngredientsList.append(ingredient.get_text())

        recipeDirections = soupRecipe.find('section', class_='recipe-directions')
        recipePrepTime = ""
        recipeCookTime = ""

        recipeTimes = recipeDirections.find('ul', class_='prepTime')
        for recipeTime in recipeTimes.find_all('li', class_='prepTime__item'):
            if recipeTime.find('p') is not None:
                if recipeTime.find('p').get_text() == "Prep":
                    recipePrepTime = recipeTime.find('span').get_text()
                elif recipeTime.find('p').get_text() == "Cook":
                    recipeCookTime = recipeTime.find('span').get_text()

        recipeDirectionsList = list()
        for recipeDirection in recipeDirections.find_all('span', class_='recipe-directions__list--item'):
            recipeDirectionsList.append(recipeDirection.get_text())

        print(recipeNameText, recipeId, recipeRating, recipePrepTime, recipeCookTime)
        for ingredient in recipeIngredientsList:
            print(ingredient, end=' ')
        for direction in recipeDirectionsList:
            print(direction, end=' ')


if __name__ == "__main__":
    main()
