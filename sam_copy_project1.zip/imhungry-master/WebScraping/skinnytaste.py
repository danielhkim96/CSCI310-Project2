import sys
import requests
import time
import json
from bs4 import BeautifulSoup


def main():

    # Get arguments from command line
    recipeSearch = ""
    for i in range(1, len(sys.argv) - 1):
        recipeSearch += sys.argv[i] + " "
    recipeSearch = recipeSearch[:-1]
    numResults = int(sys.argv[len(sys.argv) - 1])

    # Can't access skinnytaste.com if the crawler doesn't pretend to access from a browser
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.3'
    }

    recipes = list()

    # recipeSearch = input("ImHungry Search: ")
    # numResults = int(input("Number of Recipes: "))

    pageNum = 1

    # Number of recipes retrieved should be equal to numResults
    while numResults:
        # Search results of search term 'recipeSearch' on page 'pageNum'
        searchPage = requests.get("https://www.skinnytaste.com/page/" + str(pageNum) + "/?s=" + recipeSearch,
                                  headers=headers)
        # No more recipes found
        if searchPage.status_code == 404:
            break
        soup = BeautifulSoup(searchPage.content, 'html.parser')

        # Loop through each recipe on the search page
        for recipe in soup.find_all('article', class_='post'):
            if numResults:
                # time.sleep(1.5)   # crawler-delay

                # Get recipe name
                recipeTitle = recipe.find('h2', class_='title').text
                recipeLink = recipe.find('a').get('href')

                # Follow link to each recipe page
                recipePage = requests.get(recipeLink, headers=headers)
                soupRecipe = BeautifulSoup(recipePage.content, 'html.parser')

                recipeContent = soupRecipe.find('div', id='content')
                recipePost = recipeContent.find('div', class_='post')

                # Image formatting is very inconsistent, so first search through <p> tags for image
                recipeImage = ""
                for recipeImageContainer in recipePost.find_all('p'):
                    # If compatible image is found, don't continue
                    if recipeImageContainer.find('img') is not None:
                        recipeImage = recipeImageContainer.find('img').get('data-src')
                        break
                # If no images were found in <p> tags, search <div> with no class
                if recipeImage == "":
                    for recipeImageContainer in recipePost.find_all('div', class_=''):
                        if recipeImageContainer.find('img') is not None:
                            recipeImage = recipeImageContainer.find('img').get('data-src')
                            break
                # If no images were found in <div> tags, search <h2> for images
                if recipeImage == "":
                    for recipeImageContainer in recipePost.find_all('h2'):
                        if recipeImageContainer.find('img') is not None:
                            recipeImage = recipeImageContainer.find('img').get('data-src')
                            break

                recipe = recipeContent.find('div', class_='recipe')

                if recipe is not None:
                    recipeReviews = recipe.find('div', class_='rating').contents
                    recipeRating = ""
                    # Sometimes rating isn't available, check if the star rating is present
                    if len(recipeReviews) > 1:
                        recipeRating = recipe.find('div', class_='rating').contents[0].get_text().strip()

                    recipeMeta = recipe.find('div', class_='recipe-meta')
                    recipeTimes = recipeMeta.find_all('p')
                    recipePrepTime = ""
                    recipeCookTime = ""
                    recipeTotalTime = ""
                    # Prep, Cook, and Total times are all available
                    if len(recipeTimes) == 3:
                        recipePrepTime = recipeTimes[1].get_text()
                        recipeCookTime = recipeTimes[2].get_text()
                    # Only Total time is available
                    if len(recipeTimes) > 0:
                        recipeTotalTime = recipeTimes[0].get_text()

                    # Parse the ingredients list
                    recipeIngredients = list()
                    recipeIngredientsList = recipe.find('div', class_='ingredients')
                    for ingredient in recipeIngredientsList.find_all('li', class_='ingredient'):
                        recipeIngredients.append(ingredient.get_text().strip())

                    # Parse the instructions
                    recipeInstructions = list()
                    recipeInstructionsList = recipe.find('div', class_='instructions')
                    for instruction in recipeInstructionsList.find_all('li'):
                        recipeInstructions.append(instruction.get_text().strip())

                    # Store recipe as dict to convert to json
                    recipe = {
                        "title": recipeTitle,
                        "prepTime": recipePrepTime,
                        "cookTime": recipeCookTime,
                        "totalTime": recipeTotalTime,
                        "image": recipeImage,
                        "ingredients": recipeIngredients,
                        "instructions": recipeInstructions,
                        "type": "recipe",
                        "stars": recipeRating
                    }

                    # Add recipe to list of recipes
                    recipes.append(recipe)

                    numResults -= 1

                    # print(recipeTitle, recipeRating, recipePrepTime, recipeCookTime, recipeTotalTime)
                    # print('Ingredients:')
                    # for ingredient in recipeIngredients:
                    #     print(ingredient)
                    # print('Instructions:')
                    # for instruction in recipeInstructions:
                    #     print(instruction)
                    # print('')

        # If all recipes on current page were searched and more recipes are required, continue to the next page
        pageNum += 1

    # Store recipe as JSON string
    recipeJSON = json.dumps(recipes)

    print(recipeJSON)


if __name__ == "__main__":
    main()
