// put package in later

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Restaurant {

	@SerializedName("Restaurant_ID")
	@Expose
	private String restaurant_id;
	private String address;
	private String phoneNumber;
	private String website;
	int stars;
	int drivingTime;
	private String type;
	private String priceRange;
	
	
	public String getRestaurantId() {
		return restaurant_id;
	}
	
	public void setRestaurantId(String restaurant_id) {
		this.restaurant_id = restaurant_id;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getWebsite() {
		return website;
	}
	
	public void setWebsite(String website) {
		this.website = website;
	}
	
	public int getStars() {
		return stars;
	}
	
	public void setStars(int stars) {
		this.stars = stars;
	}
	
	public String getDrivingTime() {
		return drivingTime;
	}
	
	public void setDrivingTime(int drivingTime) {
		this.drivingTime = drivingTime;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getPriceRange() {
		return priceRange;
	}
	
	public void setPriceRange(String priceRange) {
		this.priceRange = priceRange;
	}
	

}