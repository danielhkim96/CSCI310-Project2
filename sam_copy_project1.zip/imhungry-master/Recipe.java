// put package in later

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Recipe {

	@SerializedName("Restaurant_ID")
	@Expose
	private String title;
	private String prepTime;
	private String cookTime;
	private String imageURL;

	private String ingredients;
	private String instructions;
	private int stars;
	private String type;
	
	
	public String getTitle() {
		return title;
	}
	
	public void setRestaurantId(String title) {
		this.title = title;
	}
	
	public String getPrepTime() {
		return prepTime;
	}
	
	public void setPrepTime(String prepTime) {
		this.prepTime = prepTime;
	}
	
	public String getCookTime() {
		return cookTime;
	}
	
	public void setCookTime(String cookTime) {
		this.cookTime = cookTime;
	}
	public String getImageURL() {
		return imageURL;
	}
	
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
	
	public int getStars() {
		return stars;
	}
	
	public void setStars(int stars) {
		this.stars = stars;
	}
	
	public String getIngredients() {
		return ingredients;
	}
	
	public void setIngredients(int ingredients) {
		this.ingredients = ingredients;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getInstructions() {
		return instructions;
	}
	
	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}
	

}