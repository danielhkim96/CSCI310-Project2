npx create-react-app myapp
cd myapp
yarn add react-router-dom --save

replace src

npm start

