CSCI310 Project 1: IM HUNGRY Backend

### Before Running:

Set the environmental variables in `setup.sh` and run `source setup.sh` in the terminal.

### Build the JAR File:

```mvn package```

### Run:

```java -jar target/backend.jar```
