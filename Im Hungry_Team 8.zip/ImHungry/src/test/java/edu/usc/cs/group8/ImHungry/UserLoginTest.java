package edu.usc.cs.group8.ImHungry;

import org.junit.Test;

public class UserLoginTest {
	
	@Test
	public void passwordIncorrect(String username, String wrongPassword)
	{
		
	}
	
	@Test
	public void passwordCorrect(String username, String rightPassword)
	{
		
	}
	
	@Test
	public void createNewAccount(String username, String password)
	{
		
	}

}
