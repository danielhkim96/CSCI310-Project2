package edu.usc.cs.group8.ImHungry;

import static org.junit.Assert.*;

import org.junit.Test;

public class DataPersistenceTest {

	@Test
	public void testListsStillThere() {
		
	}
	
	@Test
	public void testResultsStillThere() {
		
	}
	
	@Test
	public void testQuickAccessStillThere() {
		
	}
	
	@Test
	public void testListsPrivateToUser() {
		
	}
	
	@Test
	public void testResultsPrivateToUser() {
		
	}

	@Test
	public void testQuickAccessPrivateToUser() {
		
	}
}
