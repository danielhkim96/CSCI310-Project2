package edu.usc.cs.group8.ImHungry;

import static org.junit.Assert.*;

import org.junit.Test;

public class QuickAccessTest {

	@Test
	public void testQuickAccessAddition() {
		
	}
	
	@Test
	public void testQuickAccessAccess() {
		
	}

}
