package test;

import static org.junit.Assert.fail;

import org.junit.Test;

class restaurantInformationTest extends Mockito {
	
	//private getRestaurantInformation servlet;
    private MockHttpServletRequest request;
    private MockHttpServletResponse response;

	@Test
	void testGetRestaurantInformation() {
		fail("Not yet implemented");
	}

	@Test
	void testDoGetHttpServletRequestHttpServletResponse() {
		fail("Not yet implemented");
	}

	@Test
	void testGetDirectionsURL() {
		fail("Not yet implemented");
	}

}
