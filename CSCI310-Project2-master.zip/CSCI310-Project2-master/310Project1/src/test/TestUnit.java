package test;

import org.junit.Test;
import static org.junit.Assert.assertEquals;


public class TestUnit {
   
	@Test
	public void testPopulateManagementList() {
		
		
	}
	@Test
	public void testRemoveFromList() {
		
		
	}
	@Test
	public void testGetListItems() {
			
		
	}
}