package test;

public class JUnit {
	
	public int add(int n, int m) {
		return n + m;
	}

}
